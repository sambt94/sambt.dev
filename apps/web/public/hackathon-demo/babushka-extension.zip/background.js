// ABOUTME: Background service worker that calls Claude API to analyse pages and emails.
// ABOUTME: Uses sendResponse pattern to avoid service worker termination issues.

const EMAIL_PROMPT = `You are Babushka, a wise grandmother protecting someone online.

Analyse this email. Format your response EXACTLY like this:

LINE 1 (verdict — this is the most important line):
🔴 SCAM — [5 words max] OR 🟡 BE CAREFUL — [5 words max] OR 🟢 LOOKS SAFE — [5 words max]

LINE 2 (one sentence explanation):
[Plain English, max 20 words, why you gave this verdict]

LINE 3+ (details — keep brief, 2-4 short lines):
**Sender:** [who they claim to be vs actual email domain]
**Wants you to:** [what the email is asking you to do]
**Watch out for:** [any red flags, or "Nothing concerning" if safe]

Example for a scam:
🔴 SCAM — fake DPD from .jp domain
This pretends to be a delivery update but the sender address is completely wrong.
**Sender:** Claims to be DPD but sends from notifications@xyz.jp
**Wants you to:** Click a tracking link (DO NOT click it)
**Watch out for:** Link goes to a phishing site, not dpd.co.uk

Example for safe:
🟢 LOOKS SAFE — real Apple notification
Legitimate security alert from Apple about your account.
**Sender:** noreply@email.apple.com — matches Apple ✅
**Wants you to:** Know an app-specific password was created
**Watch out for:** Nothing concerning

RULES:
- #1 signal: does the sender EMAIL DOMAIN match who they CLAIM to be?
- Domain mismatch = 🔴 SCAM, always
- Urgency + unknown sender = 🟡 minimum
- Keep it SHORT. Max 6 lines total.

SENDER: {sender_name} <{sender_email}> (domain: {sender_domain})
SUBJECT: {subject}
LINKS: {links}
BODY: {body}`;

const PAYMENT_PROMPT = `You are a payment page safety analyser protecting a vulnerable user (think: someone's elderly parent).

Analyse the page and report in this EXACT format. Plain English a 65-year-old would understand.

**What you're being asked to pay:**
[Total price, what it includes]

**Is this a subscription?**
[Yes/No. If yes: how much, how often, when it renews]

**Hidden costs or catches:**
[Auto-renewals, price increases after trial, hidden fees. ⚠️ for each]

**How hard is it to cancel?**
[Cancellation method and difficulty. ⚠️ if unusually hard]

**Red flags:**
[Misleading pricing, pressure tactics, fake urgency, dark patterns. ⚠️ for each]

**Our recommendation:**
[Safe to proceed / proceed with caution / don't proceed]

RULES:
- If prominent price differs from recurring charge, flag with ⚠️
- If cancellation requires phone call, flag it
- If free trial auto-converts to paid, flag it
- Max 200 words. No jargon.

URL: {url}
TITLE: {title}
SMALL PRINT: {smallPrint}
CONTENT: {content}`;

// Keep service worker alive during long API calls
function keepAlive() {
  const interval = setInterval(() => {
    chrome.runtime.getPlatformInfo();
  }, 25000);
  return interval;
}

async function callClaude(apiKey, model, prompt) {
  const heartbeat = keepAlive();
  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true',
      },
      body: JSON.stringify({
        model: model,
        max_tokens: 1024,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    const data = await response.json();

    if (data.content && data.content[0]) {
      return { success: true, analysis: data.content[0].text };
    } else if (data.error) {
      console.error('[Babushka] API error:', data.error);
      return { success: false, analysis: `⚠️ **Analysis failed**\n\n${data.error.message}` };
    }
    return { success: false, analysis: '⚠️ **Unexpected API response**' };
  } catch (err) {
    console.error('[Babushka] Fetch error:', err);
    return { success: false, analysis: '⚠️ **Could not reach analysis service.** Check your internet connection.' };
  } finally {
    clearInterval(heartbeat);
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'ANALYZE_EMAIL') {
    console.log('[Babushka] Email analysis request:', msg.subject);

    chrome.storage.local.get(['apiKey', 'model'], async (settings) => {
      if (!settings.apiKey) {
        sendResponse({ analysis: '⚠️ **API key needed.** Click the Payment Guardian icon and enter your Anthropic API key.' });
        return;
      }

      const model = settings.model || 'claude-3-5-haiku-20241022';
      const prompt = EMAIL_PROMPT
        .replace(/{sender_name}/g, msg.sender_name || 'Unknown')
        .replace(/{sender_email}/g, msg.sender_email || 'Unknown')
        .replace(/{sender_domain}/g, msg.sender_domain || 'Unknown')
        .replace(/{subject}/g, msg.subject || '')
        .replace(/{links}/g, msg.links || 'None')
        .replace(/{body}/g, (msg.body || '').substring(0, 4000));

      const result = await callClaude(settings.apiKey, model, prompt);

      // Send Telegram alert if threat detected
      if (result.analysis && (result.analysis.includes('🔴') || result.analysis.includes('🟡'))) {
        sendTelegramAlert(msg, result.analysis).catch(() => {});
      }

      sendResponse(result);
    });

    return true; // CRITICAL: keeps message channel open for async response
  }

  if (msg.type === 'ANALYZE_PAGE') {
    console.log('[Babushka] Page analysis request:', msg.url);

    chrome.storage.local.get(['apiKey', 'model'], async (settings) => {
      if (!settings.apiKey) {
        sendResponse({ analysis: '⚠️ **API key needed.** Click the Payment Guardian icon and enter your Anthropic API key.' });
        return;
      }

      const model = settings.model || 'claude-3-5-haiku-20241022';
      const prompt = PAYMENT_PROMPT
        .replace(/{url}/g, msg.url || '')
        .replace(/{title}/g, msg.title || '')
        .replace(/{smallPrint}/g, msg.smallPrint || 'None found')
        .replace(/{content}/g, (msg.content || '').substring(0, 5000));

      const result = await callClaude(settings.apiKey, model, prompt);
      sendResponse(result);
    });

    return true;
  }

  if (msg.type === 'SUMMARISE_INBOX') {
    console.log('[Babushka] Inbox summary request:', msg.count, 'emails');

    chrome.storage.local.get(['apiKey', 'model'], async (settings) => {
      if (!settings.apiKey) {
        sendResponse({ analysis: '⚠️ API key needed. Click Babushka icon and enter your key.' });
        return;
      }

      const model = settings.model || 'claude-3-5-haiku-20241022';
      const prompt = `You are Babushka, a wise grandmother helping someone manage their inbox.

Here are ${msg.count} emails from their inbox. Categorise them and give a quick summary.

FORMAT YOUR RESPONSE EXACTLY LIKE THIS:

**🔴 Junk / Scams (delete these)**
- [sender] — [subject] — [one-line reason why it's junk]

**🟡 Marketing (up to you)**
- [sender] — [subject] — [what they're selling]

**🟢 Looks Important (read these)**
- [sender] — [subject] — [why it matters]

**📦 Newsletters / Updates (batch read later)**
- [sender] — [subject]

**👵 Babushka's advice:**
[One sentence summary. e.g. "You have 3 suspicious emails — delete those first. Then read the 2 important ones. The rest can wait."]

RULES:
- If sender domain doesn't match brand name → 🔴 Junk
- Pushy marketing with "limited time" or "$X off" → 🟡 Marketing
- Personal emails, work emails, account security → 🟢 Important
- Newsletters, product updates → 📦 Updates
- Be brief. One line per email max.
- Skip any category that has zero emails.

EMAILS:
${msg.emails}`;

      const result = await callClaude(settings.apiKey, model, prompt);
      sendResponse(result);
    });

    return true;
  }

  if (msg.type === 'GMAIL_ACTION') {
    console.log(`[Babushka] Gmail action: ${msg.action}, subject: "${msg.subject}"`);

    (async () => {
      try {
        // Step 1: Get OAuth token
        const token = await new Promise((resolve, reject) => {
          chrome.identity.getAuthToken({ interactive: true }, (tok) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else {
              resolve(tok);
            }
          });
        });
        console.log('[Babushka] Got OAuth token');

        // Helper
        async function gmailFetch(url, method = 'GET', body = null) {
          const opts = {
            method,
            headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
          };
          if (body) opts.body = JSON.stringify(body);
          return fetch(url, opts);
        }

        // Step 2: Find the email by subject search — skip DOM ID entirely
        const subject = msg.subject || '';
        const searchQuery = `subject:${subject.replace(/"/g, '').substring(0, 60)}`;
        console.log(`[Babushka] Searching: ${searchQuery}`);

        const searchResp = await gmailFetch(
          `https://www.googleapis.com/gmail/v1/users/me/messages?q=${encodeURIComponent(searchQuery)}&maxResults=3`
        );

        if (!searchResp.ok) {
          const err = await searchResp.json().catch(() => ({}));
          console.error('[Babushka] Search failed:', searchResp.status, err);
          sendResponse({ success: false, error: `Search failed: ${err.error?.message || searchResp.status}` });
          return;
        }

        const searchData = await searchResp.json();
        if (!searchData.messages || searchData.messages.length === 0) {
          console.error('[Babushka] No emails found for subject:', subject);
          sendResponse({ success: false, error: 'Email not found' });
          return;
        }

        const messageId = searchData.messages[0].id;
        const action = msg.action;
        console.log(`[Babushka] Found message ${messageId}, performing ${action}`);

        // Step 3: Perform the action
        let url, body;
        if (action === 'archive') {
          url = `https://www.googleapis.com/gmail/v1/users/me/messages/${messageId}/modify`;
          body = { removeLabelIds: ['INBOX'] };
        } else if (action === 'junk') {
          url = `https://www.googleapis.com/gmail/v1/users/me/messages/${messageId}/modify`;
          body = { addLabelIds: ['SPAM'], removeLabelIds: ['INBOX'] };
        } else if (action === 'delete') {
          url = `https://www.googleapis.com/gmail/v1/users/me/messages/${messageId}/trash`;
          body = null;
        } else {
          sendResponse({ success: false, error: `Unknown action: ${action}` });
          return;
        }

        const response = await gmailFetch(url, 'POST', body);

        if (response.ok) {
          console.log(`[Babushka] Gmail API ${action} SUCCEEDED on ${messageId}`);
          sendResponse({ success: true });
        } else {
          const errData = await response.json().catch(() => ({}));
          console.error(`[Babushka] Gmail API error:`, response.status, errData);
          sendResponse({ success: false, error: errData.error?.message || `HTTP ${response.status}` });
        }
      } catch (err) {
        console.error('[Babushka] Gmail action error:', err);
        sendResponse({ success: false, error: err.message });
      }
    })();

    return true;
  }

  if (msg.type === 'PING') {
    sendResponse({ status: 'alive' });
    return false;
  }
});

// ── TELEGRAM ALERTS — sends notification when threats are detected ──────────
async function sendTelegramAlert(emailInfo, analysis) {
  const { tgChatId } = await chrome.storage.local.get(['tgChatId']);
  const tgBotToken = '8720356348:AAFfkZ2L6oQacSRXxvwvq8e5MbXtPTlWk5o'

  if (!tgChatId) return;

  const isHigh = analysis.includes('🔴');
  const level = isHigh ? '🚨 HIGH RISK' : '⚠️ SUSPICIOUS';
  const text =
    `${level} email detected by Babushka\n\n` +
    `*From:* ${emailInfo.sender_name || emailInfo.sender_email}\n` +
    `*Subject:* ${emailInfo.subject || '(no subject)'}\n` +
    `*Analysis:* ${analysis.split('\n')[0] || '—'}`;

  try {
    await fetch(`https://api.telegram.org/bot${tgBotToken}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: tgChatId, text, parse_mode: 'Markdown' })
    });
    console.log('[Babushka] Telegram alert sent');
  } catch (err) {
    console.error('[Babushka] Telegram alert failed:', err);
  }
}

console.log('[Babushka] Service worker started');
