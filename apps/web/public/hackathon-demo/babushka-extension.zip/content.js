// ABOUTME: Content script for non-Gmail pages that detects payment forms.
// ABOUTME: Scrapes page content, sends to background worker, displays warning overlay.

(function() {
  'use strict';

  const PAYMENT_SELECTORS = [
    'input[autocomplete="cc-number"]',
    'input[autocomplete="cc-exp"]',
    'input[autocomplete="cc-csc"]',
    'input[name*="card"]',
    'input[name*="credit"]',
    'input[id*="card-number"]',
    'input[id*="card_number"]',
    'input[data-stripe]',
    'iframe[name*="__privateStripeFrame"]',
    'iframe[src*="js.braintreegateway.com"]',
    'iframe[src*="checkout.stripe.com"]',
    'form[action*="checkout"]',
    'form[action*="payment"]',
    'form[action*="subscribe"]',
    '[class*="checkout"]',
    '[class*="payment-form"]',
    '[id*="checkout"]',
    '[id*="payment"]',
  ];

  const SUBSCRIPTION_KEYWORDS = [
    'recurring', 'subscription', 'auto-renew', 'monthly', 'annually',
    'per month', 'per year', '/mo', '/yr', 'free trial', 'cancel anytime',
    'billed automatically', 'recurring charge', 'will be charged',
    'after trial', 'membership', 'plan'
  ];

  let hasScanned = false;

  function detectPaymentForm() {
    if (hasScanned) return;
    const matches = document.querySelectorAll(PAYMENT_SELECTORS.join(','));
    if (matches.length === 0) return;

    hasScanned = true;
    console.log('[Babushka] Payment form detected');

    const pageText = document.body.innerText.substring(0, 8000);
    const smallPrint = findSmallPrint();

    try {
      chrome.runtime.sendMessage({
        type: 'ANALYZE_PAGE',
        content: pageText,
        url: window.location.href,
        title: document.title,
        smallPrint: smallPrint,
      }, (response) => {
        if (chrome.runtime.lastError) {
          console.error('[Babushka]', chrome.runtime.lastError.message);
          return;
        }
        if (response && response.analysis) {
          showOverlay(response.analysis);
        }
      });
    } catch (err) {
      console.error('[Babushka] Message failed:', err);
    }
  }

  function findSmallPrint() {
    const candidates = [];
    const els = document.querySelectorAll('p, span, div, li, small, .terms, .fine-print, .disclaimer, [class*="terms"], [class*="legal"], [class*="fine"], [class*="disclaimer"]');

    for (const el of els) {
      const style = window.getComputedStyle(el);
      const fontSize = parseFloat(style.fontSize);
      const text = el.textContent.trim();
      if (!text || text.length < 20) continue;

      const isSmallFont = fontSize <= 12;
      const hasKeywords = SUBSCRIPTION_KEYWORDS.some(kw => text.toLowerCase().includes(kw));

      if (isSmallFont || hasKeywords) {
        candidates.push(text.substring(0, 500));
      }
    }
    return candidates.slice(0, 10).join('\n---\n');
  }

  function showOverlay(analysis) {
    const existing = document.getElementById('pg-overlay-container');
    if (existing) existing.remove();

    const container = document.createElement('div');
    container.id = 'pg-overlay-container';
    container.style.cssText = 'all: initial; position: fixed; top: 0; right: 0; z-index: 2147483647; font-family: system-ui, -apple-system, sans-serif;';

    const shadow = container.attachShadow({ mode: 'closed' });
    shadow.innerHTML = `
      <style>
        .pg-overlay {
          position: fixed; top: 20px; right: 20px; width: 380px; max-height: 80vh;
          overflow-y: auto; background: #fffbeb; border: 2px solid #f59e0b;
          border-radius: 16px; padding: 20px; box-shadow: 0 8px 32px rgba(0,0,0,0.2);
          font-family: system-ui, -apple-system, sans-serif; font-size: 14px;
          line-height: 1.5; color: #1a1a1a; animation: pg-slide 0.3s ease-out;
        }
        @keyframes pg-slide { from { transform: translateX(400px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        .pg-header { display: flex; align-items: center; gap: 8px; margin-bottom: 12px; padding-bottom: 12px; border-bottom: 1px solid #fde68a; }
        .pg-title { font-weight: 700; font-size: 16px; color: #92400e; flex: 1; }
        .pg-close { background: none; border: none; font-size: 20px; cursor: pointer; color: #92400e; padding: 4px 8px; border-radius: 6px; }
        .pg-close:hover { background: #fde68a; }
        .pg-body { white-space: pre-wrap; word-wrap: break-word; }
        .pg-actions { display: flex; gap: 8px; margin-top: 16px; padding-top: 12px; border-top: 1px solid #fde68a; }
        .pg-btn { flex: 1; padding: 10px 16px; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; border: none; }
        .pg-btn-back { background: #f59e0b; color: white; }
        .pg-btn-back:hover { background: #d97706; }
        .pg-btn-proceed { background: #e5e7eb; color: #4b5563; }
        .pg-btn-proceed:hover { background: #d1d5db; }
        .pg-powered { text-align: center; font-size: 11px; color: #9ca3af; margin-top: 12px; }
      </style>
      <div class="pg-overlay">
        <div class="pg-header">
          <span style="font-size:24px">🛡️</span>
          <span class="pg-title">👵 Babushka says, before you pay:</span>
          <button class="pg-close" id="close">&times;</button>
        </div>
        <div class="pg-body" id="body"></div>
        <div class="pg-actions">
          <button class="pg-btn pg-btn-back" id="back">Go back</button>
          <button class="pg-btn pg-btn-proceed" id="proceed">Proceed anyway</button>
        </div>
        <div class="pg-powered">Powered by Babushka 👵</div>
      </div>
    `;

    document.body.appendChild(container);

    const bodyEl = shadow.getElementById('body');
    bodyEl.innerHTML = analysis
      .replace(/⚠️/g, '<span style="color:#dc2626">⚠️</span>')
      .replace(/✅/g, '<span style="color:#16a34a">✅</span>')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\n/g, '<br>');

    shadow.getElementById('close').addEventListener('click', () => container.remove());
    shadow.getElementById('back').addEventListener('click', () => { container.remove(); window.history.back(); });
    shadow.getElementById('proceed').addEventListener('click', () => container.remove());
  }

  // Listen for manual scan from popup
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'force_scan') {
      hasScanned = false;
      const pageText = document.body.innerText.substring(0, 8000);
      chrome.runtime.sendMessage({
        type: 'ANALYZE_PAGE',
        content: pageText,
        url: window.location.href,
        title: document.title,
        smallPrint: findSmallPrint(),
      }, (response) => {
        if (response && response.analysis) showOverlay(response.analysis);
      });
    }
  });

  // Auto-detect payment forms
  detectPaymentForm();

  // Watch for dynamically loaded forms (SPAs)
  const observer = new MutationObserver(() => {
    if (!hasScanned) detectPaymentForm();
  });
  observer.observe(document.body, { childList: true, subtree: true });

  console.log('[Babushka] Content script loaded on', window.location.hostname);
})();
