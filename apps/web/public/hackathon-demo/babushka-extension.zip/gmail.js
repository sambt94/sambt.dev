// ABOUTME: Gmail content script that detects open emails and injects inline safety banners.
// ABOUTME: Uses MutationObserver to wait for Gmail DOM, injects banners above email body.

(function() {
  'use strict';

  console.log('[Babushka] gmail.js loaded at', new Date().toISOString());

  // Track which emails we've already scanned
  const scannedEmails = new Set();

  // Wait for Gmail to actually render its UI before doing anything
  function waitForGmail(callback) {
    // Gmail's main content pane has role="main" or class .aeJ
    const check = () => {
      const main = document.querySelector('[role="main"]') || document.querySelector('.aeJ');
      if (main) {
        console.log('[Babushka] Gmail UI ready');
        callback();
        return true;
      }
      return false;
    };

    if (check()) return;

    // Gmail hasn't rendered yet — watch for it
    const observer = new MutationObserver(() => {
      if (check()) observer.disconnect();
    });
    observer.observe(document.body, { childList: true, subtree: true });

    // Safety timeout — stop waiting after 30s
    setTimeout(() => observer.disconnect(), 30000);
  }

  // Get sender info scoped to a specific email body element
  function getSenderInfo(bodyEl) {
    // Walk UP from the email body to find the message container
    // Gmail structure: message container > ... > div.a3s (body)
    // The sender [email] element is in the message header, a sibling/ancestor of the body
    let container = bodyEl;
    for (let i = 0; i < 15; i++) {
      container = container.parentElement;
      if (!container) break;

      // Look for [data-message-id] which wraps the full message
      if (container.getAttribute('data-message-id')) break;

      // Also check for the message wrapper class
      if (container.classList.contains('kv') || container.classList.contains('adn')) break;
    }

    if (!container) container = bodyEl.parentElement;

    // Now search within this message container for sender info
    const emailEl = container.querySelector('[email]');
    if (emailEl) {
      return {
        email: emailEl.getAttribute('email') || '',
        name: emailEl.getAttribute('name') || emailEl.textContent.trim() || '',
      };
    }

    const gdEl = container.querySelector('.gD');
    if (gdEl) {
      return {
        email: gdEl.getAttribute('email') || '',
        name: gdEl.getAttribute('name') || gdEl.textContent.trim() || '',
      };
    }

    // Last resort: search upwards more broadly
    const broader = bodyEl.closest('[role="listitem"]') || bodyEl.closest('.gs');
    if (broader) {
      const el = broader.querySelector('[email]') || broader.querySelector('.gD');
      if (el) {
        return {
          email: el.getAttribute('email') || '',
          name: el.getAttribute('name') || el.textContent.trim() || '',
        };
      }
    }

    return null;
  }

  // Get subject line
  function getSubject() {
    const h2 = document.querySelector('h2.hP')
      || document.querySelector('[data-legacy-thread-id] h2')
      || document.querySelector('h2[data-thread-perm-id]');
    if (h2) return h2.textContent.trim();
    return document.title.replace(/ - .*$/, '').trim();
  }

  // Get links from email body
  function getEmailLinks(bodyEl) {
    return Array.from(bodyEl.querySelectorAll('a[href]'))
      .map(a => ({
        text: a.textContent.trim().substring(0, 80),
        href: a.href,
      }))
      .filter(l => l.href && !l.href.startsWith('mailto:'))
      .slice(0, 20);
  }

  // Create a unique fingerprint for an email to avoid re-scanning
  function getFingerprint(bodyEl) {
    const msgId = bodyEl.closest('[data-message-id]');
    if (msgId) return msgId.getAttribute('data-message-id');
    // Fallback: hash of first 200 chars
    return bodyEl.textContent.substring(0, 200).trim();
  }

  // Inject a banner above the email body
  function injectBanner(bodyEl, type, content) {
    // Remove any existing banner for this email
    const existing = bodyEl.parentElement?.querySelector('.pg-banner');
    if (existing) existing.remove();

    // Parse verdict line vs details from the content
    let verdictLine = content;
    let details = '';
    if (type !== 'loading' && type !== 'error') {
      const lines = content.split('<br>');
      verdictLine = lines[0] || content;
      details = lines.slice(1).join('<br>').trim();
    }

    const banner = document.createElement('div');
    banner.className = `pg-banner pg-banner-${type}`;

    const verdictEmoji = type === 'danger' ? '🔴' : type === 'warning' ? '🟡' : type === 'safe' ? '🟢' : '👵';

    banner.innerHTML = `
      <div class="pg-banner-header">
        <span class="pg-banner-icon">${verdictEmoji}</span>
        <span class="pg-banner-title">${type === 'loading' ? 'Babushka is reading...' : '👵 Babushka says:'}</span>
        <button class="pg-banner-close">&times;</button>
      </div>
      <div class="pg-banner-verdict">${verdictLine}</div>
      ${details ? `
      <div class="pg-banner-toggle">
        <span class="pg-toggle-text">More details ▼</span>
      </div>
      <div class="pg-banner-details pg-collapsed-details">${details}</div>
      ` : ''}
    `;

    // Close button
    banner.querySelector('.pg-banner-close').addEventListener('click', () => {
      banner.remove();
    });

    // Toggle details
    const toggle = banner.querySelector('.pg-banner-toggle');
    if (toggle) {
      toggle.addEventListener('click', () => {
        const detailsEl = banner.querySelector('.pg-banner-details');
        const toggleText = banner.querySelector('.pg-toggle-text');
        if (detailsEl) {
          detailsEl.classList.toggle('pg-collapsed-details');
          toggleText.textContent = detailsEl.classList.contains('pg-collapsed-details')
            ? 'More details ▼' : 'Less details ▲';
        }
      });
    }

    // Insert above email body
    bodyEl.parentElement?.insertBefore(banner, bodyEl);
  }

  // Get the Gmail message ID from the current email view
  // Gmail API needs the message ID, not the thread ID
  function getMessageId(bodyEl) {
    // Collect all possible IDs for debugging
    const ids = {};

    // Strategy 1: data-message-id on a parent (format: msg-f:XXXXXXX or just hex)
    const msgContainer = bodyEl.closest('[data-message-id]');
    if (msgContainer) {
      ids.dataMessageId = msgContainer.getAttribute('data-message-id');
    }

    // Strategy 2: data-legacy-message-id
    const legacyContainer = bodyEl.closest('[data-legacy-message-id]');
    if (legacyContainer) {
      ids.legacyMessageId = legacyContainer.getAttribute('data-legacy-message-id');
    }

    // Strategy 3: broader search
    const allMsgIds = document.querySelectorAll('[data-message-id]');
    if (allMsgIds.length > 0) {
      ids.lastDataMessageId = allMsgIds[allMsgIds.length - 1].getAttribute('data-message-id');
    }

    // Strategy 4: extract from URL hash — Gmail uses #inbox/MESSAGEID format
    const hash = window.location.hash;
    const hashMatch = hash.match(/#(?:inbox|sent|all|trash|spam|label\/[^/]+)\/([A-Za-z0-9]+)$/);
    if (hashMatch) {
      ids.urlId = hashMatch[1];
    }

    // Strategy 5: data-legacy-thread-id on thread container
    const threadContainer = document.querySelector('[data-legacy-thread-id]');
    if (threadContainer) {
      ids.legacyThreadId = threadContainer.getAttribute('data-legacy-thread-id');
    }

    console.log('[Babushka] All IDs found:', JSON.stringify(ids));

    // The Gmail API typically works with the hex message ID
    // data-message-id can be in format "#msg-f:XXXX" — we need just the hex part
    // Or it might already be the right format
    // Priority: URL hash ID > data-message-id > legacy
    return ids.urlId || ids.dataMessageId || ids.legacyMessageId || ids.lastDataMessageId || null;
  }

  // Perform Gmail actions via Gmail API (through background script)
  function performAction(action, bodyEl) {
    if (action === 'keep' || action === 'star') return;

    console.log(`[Babushka] Performing action: ${action}`);

    // Get the message ID from the DOM
    const rawId = bodyEl ? getMessageId(bodyEl) : null;

    if (!rawId) {
      console.warn('[Babushka] Could not find message ID');
      showActionToast(action, true);
      return;
    }

    // Clean the ID — strip prefixes like "msg-f:" or "#msg-f:"
    const messageId = rawId.replace(/^#?msg-[fa]:/g, '').trim();
    const subject = getSubject();
    console.log(`[Babushka] Raw ID: ${rawId}, cleaned: ${messageId}, subject: "${subject}", action: ${action}`);

    chrome.runtime.sendMessage({
      type: 'GMAIL_ACTION',
      action: action,
      messageId: messageId,
      rawId: rawId,
      subject: subject,
    }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('[Babushka] Action error:', chrome.runtime.lastError.message);
        showActionToast(action, true);
        return;
      }
      if (response && response.success) {
        console.log(`[Babushka] ${action} succeeded via Gmail API`);
        showActionToast(action);
        // Navigate back to inbox after a short delay
        setTimeout(() => {
          window.location.hash = '#inbox';
        }, 800);
      } else {
        console.error('[Babushka] Action failed:', response?.error);
        showActionToast(action, true);
      }
    });
  }

  // Show a toast notification after an action
  function showActionToast(action, failed = false) {
    const existing = document.getElementById('babushka-toast');
    if (existing) existing.remove();

    const messages = {
      archive: failed ? '📦 Couldn\'t archive — try the Gmail button above' : '📦 Archived! Babushka tidied that up.',
      junk: failed ? '🗑️ Couldn\'t junk — try Gmail\'s spam button above' : '🗑️ Junked! Babushka threw that out.',
      delete: failed ? '❌ Couldn\'t delete' : '❌ Deleted!',
    };

    const toast = document.createElement('div');
    toast.id = 'babushka-toast';
    toast.textContent = messages[action] || (failed ? 'Action failed' : 'Done!');
    toast.style.cssText = `
      position: fixed; bottom: 90px; right: 28px; z-index: 99999;
      padding: 12px 20px; border-radius: 12px;
      background: ${failed ? '#fef2f2' : '#ecfdf5'};
      border: 1px solid ${failed ? '#fecaca' : '#a7f3d0'};
      color: ${failed ? '#991b1b' : '#065f46'};
      font-family: system-ui, -apple-system, sans-serif;
      font-size: 14px; font-weight: 600;
      box-shadow: 0 4px 16px rgba(0,0,0,0.1);
      animation: babushka-toast-in 0.3s ease-out;
    `;

    // Add animation keyframes if not already present
    if (!document.getElementById('babushka-toast-style')) {
      const style = document.createElement('style');
      style.id = 'babushka-toast-style';
      style.textContent = `
        @keyframes babushka-toast-in {
          from { transform: translateY(20px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
      `;
      document.head.appendChild(style);
    }

    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.transition = 'opacity 0.3s, transform 0.3s';
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  // Format the analysis response into HTML
  function formatAnalysis(text) {
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/🔴/g, '<span class="pg-red">🔴</span>')
      .replace(/🟡/g, '<span class="pg-amber">🟡</span>')
      .replace(/🟢/g, '<span class="pg-green">🟢</span>')
      .replace(/⚠️/g, '<span class="pg-red">⚠️</span>')
      .replace(/✅/g, '<span class="pg-green">✅</span>')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\n/g, '<br>');
  }

  // Scan a single email body element
  function scanEmail(bodyEl) {
    const fingerprint = getFingerprint(bodyEl);
    if (scannedEmails.has(fingerprint)) return;
    scannedEmails.add(fingerprint);

    const sender = getSenderInfo(bodyEl);
    if (!sender) {
      console.log('[Babushka] No sender info found, skipping');
      return;
    }

    const subject = getSubject();
    const bodyText = bodyEl.textContent.substring(0, 6000);
    const links = getEmailLinks(bodyEl);
    const senderDomain = sender.email.split('@')[1] || 'unknown';

    // Skip very short email fragments (signatures, quoted text)
    if (bodyText.trim().length < 80) return;

    console.log(`[Babushka] Scanning: "${subject}" from ${sender.name} <${sender.email}>`);

    // Show loading banner
    injectBanner(bodyEl, 'loading', '<div class="pg-pulse">Let me take a look at this, dear...</div>');

    // Send to background service worker
    try {
      chrome.runtime.sendMessage({
        type: 'ANALYZE_EMAIL',
        sender_name: sender.name,
        sender_email: sender.email,
        sender_domain: senderDomain,
        subject: subject,
        body: bodyText,
        links: JSON.stringify(links),
      }, (response) => {
        if (chrome.runtime.lastError) {
          console.error('[Babushka] Message error:', chrome.runtime.lastError.message);
          injectBanner(bodyEl, 'error', 'Could not connect to analysis service. Try refreshing the page.');
          return;
        }
        if (response && response.analysis) {
          const formatted = formatAnalysis(response.analysis);
          const type = response.analysis.includes('🔴') ? 'danger' :
                       response.analysis.includes('🟡') ? 'warning' : 'safe';
          injectBanner(bodyEl, type, formatted);
        }
      });
    } catch (err) {
      console.error('[Babushka] Failed to send message:', err);
      injectBanner(bodyEl, 'error', 'Extension disconnected. Please refresh the page.');
    }
  }

  // Main scan loop: find all unscanned email bodies
  function scanForEmails() {
    const emailBodies = document.querySelectorAll('div.a3s:not([data-pg-scanned])');
    console.log(`[Babushka] Found ${emailBodies.length} unscanned email bodies`);
    emailBodies.forEach(bodyEl => {
      // Mark as scanned immediately to prevent double-scanning
      bodyEl.setAttribute('data-pg-scanned', 'true');

      // Skip tiny fragments
      if (bodyEl.textContent.trim().length < 80) return;

      scanEmail(bodyEl);
    });
  }

  // Reset scan state on navigation so emails get re-scanned
  function resetScanState() {
    document.querySelectorAll('[data-pg-scanned]').forEach(el => {
      el.removeAttribute('data-pg-scanned');
    });
    // Don't clear scannedEmails set — fingerprints prevent true duplicates
  }

  // Inject Babushka button into Gmail — always use floating button for reliability
  function injectToolbarButton() {
    // Only show on inbox view, not when reading an email
    const hash = window.location.hash;
    const isInbox = !hash || hash === '#inbox' || hash.match(/^#inbox$/);
    const existing = document.getElementById('babushka-main-btn');

    // Remove button if we're not on inbox
    if (!isInbox) {
      if (existing) existing.remove();
      return;
    }

    if (existing) return;

    // Inject CSS once
    if (!document.getElementById('babushka-btn-style')) {
      const style = document.createElement('style');
      style.id = 'babushka-btn-style';
      style.textContent = `
        @keyframes babushka-shine {
          0% { left: -100%; }
          100% { left: 100%; }
        }
        #babushka-main-btn {
          display: inline-flex; align-items: center; gap: 8px;
          padding: 8px 18px; border-radius: 20px;
          background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
          color: white; font-weight: 700; font-size: 13px;
          font-family: system-ui, -apple-system, sans-serif;
          cursor: pointer; border: none;
          box-shadow: 0 2px 8px rgba(217,119,6,0.3);
          transition: all 0.15s ease;
          overflow: hidden; position: relative;
          user-select: none; margin-left: 12px;
          vertical-align: middle;
        }
        #babushka-main-btn:hover {
          transform: scale(1.04);
          box-shadow: 0 4px 16px rgba(217,119,6,0.4);
        }
        #babushka-main-btn:active {
          transform: scale(0.97);
        }
        #babushka-main-btn .bb-shine {
          position: absolute; top: 0; left: -100%; width: 60%; height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
          pointer-events: none;
        }
        #babushka-main-btn:hover .bb-shine {
          animation: babushka-shine 0.6s ease;
        }
      `;
      document.head.appendChild(style);
    }

    const btn = document.createElement('div');
    btn.id = 'babushka-main-btn';
    btn.innerHTML = `
      <span class="bb-shine"></span>
      <span style="font-size:16px">👵</span>
      <span>Run Babushka</span>
    `;
    btn.addEventListener('click', triggerInboxSummary);

    // Try to inject next to Gmail's toolbar (near Compose button or search bar)
    const toolbar = document.querySelector('.aeH') // Gmail top toolbar
      || document.querySelector('[gh="tm"]') // Toolbar menu
      || document.querySelector('.G-atb'); // Action toolbar above emails

    if (toolbar) {
      toolbar.appendChild(btn);
      console.log('[Babushka] Button injected in toolbar');
    } else {
      // Fallback: inject above the email list
      const emailList = document.querySelector('[role="main"]');
      if (emailList) {
        emailList.insertBefore(btn, emailList.firstChild);
        console.log('[Babushka] Button injected above email list');
      } else {
        document.body.appendChild(btn);
        console.log('[Babushka] Button injected (fallback)');
      }
    }
  }

  // Cooking animation phrases — Babushka is in the kitchen
  const COOKING_PHASES = [
    { emoji: '👵🔍', text: 'Babushka is putting on her reading glasses...' },
    { emoji: '📬👀', text: 'Opening the mailbox...' },
    { emoji: '🍲📧', text: 'Sorting the letters on the kitchen table...' },
    { emoji: '🧐✉️', text: 'Reading each one carefully...' },
    { emoji: '👃🐟', text: 'Hmm, some of these smell fishy...' },
    { emoji: '📝✨', text: 'Writing up her notes...' },
  ];

  // Cooking loader — uses its own container so we can animate
  let cookingInterval = null;

  function showCookingLoader() {
    // Clean up any previous
    if (cookingInterval) clearInterval(cookingInterval);
    const existing = document.getElementById('pg-summary-overlay');
    if (existing) existing.remove();

    const container = document.createElement('div');
    container.id = 'pg-summary-overlay';
    container.style.cssText = 'all: initial; position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 2147483647; font-family: system-ui, -apple-system, sans-serif;';

    // Use open shadow so we can update it
    const shadow = container.attachShadow({ mode: 'open' });
    shadow.innerHTML = `
      <style>
        .pg-cook-backdrop {
          position: fixed; top: 0; left: 0; width: 100%; height: 100%;
          background: rgba(0,0,0,0.6); display: flex; justify-content: center; align-items: center;
        }
        .pg-cook-card {
          width: 420px; background: #fffbeb; border-radius: 24px;
          padding: 50px 40px; text-align: center;
          box-shadow: 0 16px 64px rgba(0,0,0,0.35);
          animation: pg-pop 0.25s ease-out;
        }
        @keyframes pg-pop {
          from { transform: scale(0.9); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }
        .cook-emoji {
          font-size: 72px; margin-bottom: 24px;
          transition: transform 0.3s ease;
          display: block;
        }
        .cook-text {
          font-size: 17px; color: #92400e; font-weight: 600;
          margin-bottom: 8px; min-height: 28px;
          transition: opacity 0.2s;
        }
        .cook-sub {
          font-size: 12px; color: #b45309; opacity: 0.7;
        }
        .cook-dots {
          margin-top: 24px; display: flex; justify-content: center; gap: 8px;
        }
        .cook-dot {
          width: 10px; height: 10px; border-radius: 50%;
          background: #f59e0b; display: inline-block;
        }
        .cook-dot:nth-child(1) { animation: pg-bounce 1.4s ease-in-out infinite; }
        .cook-dot:nth-child(2) { animation: pg-bounce 1.4s ease-in-out 0.2s infinite; }
        .cook-dot:nth-child(3) { animation: pg-bounce 1.4s ease-in-out 0.4s infinite; }
        @keyframes pg-bounce {
          0%, 80%, 100% { transform: scale(0.5); opacity: 0.3; }
          40% { transform: scale(1); opacity: 1; }
        }
        .cook-progress {
          margin-top: 28px; height: 4px; background: #fde68a;
          border-radius: 2px; overflow: hidden;
        }
        .cook-progress-bar {
          height: 100%; background: #f59e0b; border-radius: 2px;
          width: 0%; transition: width 2s ease;
        }
      </style>
      <div class="pg-cook-backdrop">
        <div class="pg-cook-card">
          <span class="cook-emoji" id="emoji">👵🔍</span>
          <div class="cook-text" id="text">Babushka is putting on her reading glasses...</div>
          <div class="cook-sub">Checking your inbox</div>
          <div class="cook-dots">
            <span class="cook-dot"></span>
            <span class="cook-dot"></span>
            <span class="cook-dot"></span>
          </div>
          <div class="cook-progress">
            <div class="cook-progress-bar" id="progress"></div>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(container);

    // Animate progress bar
    requestAnimationFrame(() => {
      const progressBar = shadow.getElementById('progress');
      if (progressBar) progressBar.style.width = '85%';
    });

    // Cycle through phases
    let phase = 0;
    cookingInterval = setInterval(() => {
      phase++;
      if (phase >= COOKING_PHASES.length) {
        clearInterval(cookingInterval);
        cookingInterval = null;
        return;
      }
      const emojiEl = shadow.getElementById('emoji');
      const textEl = shadow.getElementById('text');
      if (emojiEl && textEl) {
        emojiEl.style.transform = 'scale(0.7) rotate(-5deg)';
        textEl.style.opacity = '0';
        setTimeout(() => {
          emojiEl.textContent = COOKING_PHASES[phase].emoji;
          emojiEl.style.transform = 'scale(1) rotate(0deg)';
          textEl.textContent = COOKING_PHASES[phase].text;
          textEl.style.opacity = '1';
        }, 200);
      }
    }, 2000);
  }

  // Cycle through cooking phases
  function startCookingAnimation(shadow) {
    let phase = 0;
    const interval = setInterval(() => {
      phase++;
      if (phase >= COOKING_PHASES.length) {
        clearInterval(interval);
        return;
      }
      const emojiEl = shadow?.getElementById?.('cooking-emoji');
      const textEl = shadow?.getElementById?.('cooking-text');
      if (emojiEl && textEl) {
        emojiEl.style.transform = 'scale(0.8)';
        setTimeout(() => {
          emojiEl.textContent = COOKING_PHASES[phase].emoji;
          emojiEl.style.transform = 'scale(1)';
          textEl.textContent = COOKING_PHASES[phase].text;
        }, 150);
      }
    }, 2500);
    return interval;
  }

  // Trigger the inbox summary
  function triggerInboxSummary() {
    // Disable button while working
    const btn = document.getElementById('babushka-main-btn');
    if (btn) {
      btn.style.pointerEvents = 'none';
      btn.style.opacity = '0.6';
      btn.style.animation = 'none';
    }

    const emails = scrapeInbox();

    if (emails.length === 0) {
      showSummaryOverlay('👵 I can\'t see any emails here, dear. Make sure you\'re looking at your inbox.');
      if (btn) { btn.style.pointerEvents = ''; btn.style.opacity = ''; }
      return;
    }

    const emailList = emails.map((e, i) =>
      `${i + 1}. FROM: ${e.sender} <${e.email}> | SUBJECT: ${e.subject} | PREVIEW: ${e.snippet} | DATE: ${e.date} | ${e.unread ? 'UNREAD' : 'read'}`
    ).join('\n');

    // Show cooking loader with grandma animation
    showCookingLoader();

    chrome.runtime.sendMessage({
      type: 'SUMMARISE_INBOX',
      emails: emailList,
      count: emails.length,
    }, (response) => {
      // Stop cooking animation
      if (cookingInterval) { clearInterval(cookingInterval); cookingInterval = null; }

      // Re-enable button
      if (btn) {
        btn.style.pointerEvents = '';
        btn.style.opacity = '';
        btn.style.animation = 'babushka-gentle-bob 3s ease-in-out infinite';
      }

      if (chrome.runtime.lastError) {
        showSummaryOverlay('⚠️ Could not connect to Babushka. Try refreshing the page.');
        return;
      }
      if (response && response.analysis) {
        showSummaryOverlay(response.analysis);
      }
    });
  }

  // Start watching Gmail for email opens
  function startWatching() {
    console.log('[Babushka] Starting email watcher');

    // Inject toolbar button
    injectToolbarButton();

    // Initial scan
    scanForEmails();

    // Watch for new emails being opened (Gmail is an SPA)
    const observer = new MutationObserver(() => {
      // Debounce — Gmail fires many mutations per navigation
      clearTimeout(observer._debounce);
      observer._debounce = setTimeout(() => {
        scanForEmails();
        // Re-inject button if Gmail re-rendered the toolbar
        injectToolbarButton();
      }, 600);
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });

    // Also watch hash changes (Gmail uses hash routing)
    window.addEventListener('hashchange', () => {
      console.log('[Babushka] Navigation detected — resetting scan state');
      resetScanState();
      setTimeout(() => {
        scanForEmails();
        injectToolbarButton();
      }, 800);
    });
  }

  // Scrape visible inbox emails for summary
  function scrapeInbox() {
    const emails = [];
    // Gmail inbox rows — each row is a <tr> in the email list
    const rows = document.querySelectorAll('tr.zA');

    rows.forEach((row, i) => {
      if (i >= 30) return; // Cap at 30 emails

      // Sender name
      const senderEl = row.querySelector('.yW .bA4 [email]')
        || row.querySelector('.yW [email]')
        || row.querySelector('.yW');
      const senderName = senderEl?.getAttribute('name') || senderEl?.textContent.trim() || 'Unknown';
      const senderEmail = senderEl?.getAttribute('email') || '';

      // Subject
      const subjectEl = row.querySelector('.bog .bqe') || row.querySelector('.bog');
      const subject = subjectEl?.textContent.trim() || '';

      // Snippet / preview
      const snippetEl = row.querySelector('.y2');
      const snippet = snippetEl?.textContent.replace(/^\s*-\s*/, '').trim() || '';

      // Date
      const dateEl = row.querySelector('.xW .xY span');
      const date = dateEl?.getAttribute('title') || dateEl?.textContent.trim() || '';

      // Unread?
      const unread = row.classList.contains('zE');

      if (subject || senderName) {
        emails.push({
          sender: senderName,
          email: senderEmail,
          subject: subject,
          snippet: snippet.substring(0, 100),
          date: date,
          unread: unread,
        });
      }
    });

    console.log(`[Babushka] Scraped ${emails.length} inbox emails`);
    return emails;
  }

  // Show the inbox summary overlay — structured version with action buttons
  function showSummaryOverlay(summary) {
    const existing = document.getElementById('pg-summary-overlay');
    if (existing) existing.remove();

    const container = document.createElement('div');
    container.id = 'pg-summary-overlay';
    container.style.cssText = 'all: initial; position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 2147483647; font-family: system-ui, -apple-system, sans-serif;';

    const shadow = container.attachShadow({ mode: 'closed' });
    shadow.innerHTML = `
      <style>
        * { box-sizing: border-box; }
        .pg-backdrop {
          position: fixed; top: 0; left: 0; width: 100%; height: 100%;
          background: rgba(0,0,0,0.6); display: flex; justify-content: center;
          align-items: flex-start; padding-top: 30px; overflow-y: auto;
        }
        .pg-summary {
          width: 680px; max-height: 90vh; overflow-y: auto;
          background: #fafaf9; border-radius: 20px; padding: 0;
          box-shadow: 0 16px 64px rgba(0,0,0,0.35);
          animation: pg-pop 0.25s ease-out;
        }
        @keyframes pg-pop {
          from { transform: scale(0.95) translateY(10px); opacity: 0; }
          to { transform: scale(1) translateY(0); opacity: 1; }
        }

        /* Header */
        .pg-sum-header {
          display: flex; align-items: center; gap: 12px;
          padding: 24px 28px 20px; background: #fffbeb;
          border-bottom: 2px solid #fde68a;
          border-radius: 20px 20px 0 0;
          position: sticky; top: 0; z-index: 10;
        }
        .pg-sum-title { font-size: 22px; font-weight: 800; color: #92400e; flex: 1; }
        .pg-sum-subtitle { font-size: 13px; color: #b45309; font-weight: 400; }
        .pg-sum-close {
          background: none; border: none; font-size: 24px;
          cursor: pointer; color: #92400e; padding: 4px 10px; border-radius: 8px;
        }
        .pg-sum-close:hover { background: #fde68a; }

        /* Body */
        .pg-sum-body { padding: 20px 28px 28px; }

        /* Loading state */
        .pg-loading {
          text-align: center; padding: 60px 20px;
          font-size: 16px; color: #92400e;
          animation: pg-pulse-fade 1.5s ease-in-out infinite;
        }
        @keyframes pg-pulse-fade {
          0%, 100% { opacity: 0.5; }
          50% { opacity: 1; }
        }

        /* Category cards */
        .pg-card {
          margin-bottom: 16px; border-radius: 14px;
          overflow: hidden; border: 1px solid #e5e7eb;
          background: white;
        }
        .pg-card-header {
          display: flex; align-items: center; gap: 10px;
          padding: 14px 18px; font-weight: 700; font-size: 14px;
          cursor: pointer; user-select: none;
        }
        .pg-card-header .pg-chevron {
          margin-left: 4px; font-size: 12px; transition: transform 0.2s;
          color: inherit; opacity: 0.5;
        }
        .pg-card.pg-collapsed .pg-card-header .pg-chevron { transform: rotate(-90deg); }
        .pg-card-body { overflow: hidden; transition: max-height 0.3s ease; }
        .pg-card.pg-collapsed .pg-card-body { max-height: 0 !important; }
        .pg-card-header .pg-count {
          margin-left: auto; font-size: 12px; font-weight: 600;
          padding: 2px 10px; border-radius: 12px; background: rgba(0,0,0,0.06);
        }
        .pg-card-danger .pg-card-header { background: #fef2f2; color: #991b1b; border-bottom: 2px solid #fecaca; }
        .pg-card-warning .pg-card-header { background: #fffbeb; color: #92400e; border-bottom: 2px solid #fde68a; }
        .pg-card-safe .pg-card-header { background: #ecfdf5; color: #065f46; border-bottom: 2px solid #a7f3d0; }
        .pg-card-info .pg-card-header { background: #eef2ff; color: #3730a3; border-bottom: 2px solid #c7d2fe; }

        /* Bulk action button in card header */
        .pg-bulk-btn {
          margin-left: 8px; padding: 5px 12px; border-radius: 8px;
          font-size: 11px; font-weight: 700; cursor: pointer;
          border: none; color: white; transition: opacity 0.1s;
        }
        .pg-bulk-btn:hover { opacity: 0.85; }
        .pg-bulk-danger { background: #ef4444; }
        .pg-bulk-warning { background: #f59e0b; }
        .pg-bulk-safe { background: #10b981; }

        /* Email rows */
        .pg-email-row {
          display: flex; align-items: center; gap: 12px;
          padding: 10px 18px; border-bottom: 1px solid #f3f4f6;
          font-size: 13px; transition: background 0.1s;
        }
        .pg-email-row:last-child { border-bottom: none; }
        .pg-email-row:hover { background: #f9fafb; }
        .pg-email-info { flex: 1; min-width: 0; }
        .pg-email-sender { font-weight: 600; color: #374151; }
        .pg-email-subject { color: #6b7280; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .pg-email-reason { font-size: 11px; color: #9ca3af; margin-top: 2px; }

        /* Per-email action buttons */
        .pg-row-actions { display: flex; gap: 4px; flex-shrink: 0; }
        .pg-row-btn {
          padding: 5px 8px; border-radius: 6px; font-size: 12px;
          cursor: pointer; border: 1px solid #e5e7eb; background: white;
          transition: all 0.1s;
        }
        .pg-row-btn:hover { background: #f3f4f6; transform: scale(1.05); }
        .pg-row-btn-done { background: #d1fae5; border-color: #a7f3d0; color: #065f46; pointer-events: none; }

        /* Advice footer */
        .pg-advice {
          margin-top: 20px; padding: 16px 20px; border-radius: 14px;
          background: #fffbeb; border: 2px solid #fde68a;
          font-size: 14px; line-height: 1.5; color: #92400e;
        }
        .pg-advice strong { color: #78350f; }

        /* Powered footer */
        .pg-powered {
          text-align: center; font-size: 11px; color: #9ca3af;
          margin-top: 16px; padding-top: 12px; border-top: 1px solid #e5e7eb;
        }

        /* Scrollbar */
        .pg-summary::-webkit-scrollbar { width: 6px; }
        .pg-summary::-webkit-scrollbar-track { background: transparent; }
        .pg-summary::-webkit-scrollbar-thumb { background: #d6d3d1; border-radius: 3px; }
      </style>
      <div class="pg-backdrop" id="backdrop">
        <div class="pg-summary">
          <div class="pg-sum-header">
            <span style="font-size:28px">👵</span>
            <div>
              <div class="pg-sum-title">Babushka's Inbox Report</div>
              <div class="pg-sum-subtitle">Here's what I found, dear</div>
            </div>
            <button class="pg-sum-close" id="close">&times;</button>
          </div>
          <div class="pg-sum-body" id="body"></div>
        </div>
      </div>
    `;

    document.body.appendChild(container);

    const bodyEl = shadow.getElementById('body');
    bodyEl.innerHTML = formatSummary(summary);

    // Wire up action buttons after rendering
    wireActionButtons(shadow);

    shadow.getElementById('close').addEventListener('click', () => container.remove());
    shadow.getElementById('backdrop').addEventListener('click', (e) => {
      if (e.target.id === 'backdrop') container.remove();
    });

    // ESC to close
    const escHandler = (e) => {
      if (e.key === 'Escape') { container.remove(); document.removeEventListener('keydown', escHandler); }
    };
    document.addEventListener('keydown', escHandler);
  }

  // Wire up action buttons in the summary overlay
  function wireActionButtons(shadow) {
    // Collapsible sections
    shadow.querySelectorAll('.pg-card-header').forEach(header => {
      header.addEventListener('click', (e) => {
        // Don't collapse when clicking bulk action button
        if (e.target.closest('.pg-bulk-btn')) return;
        const card = header.closest('.pg-card');
        if (card) card.classList.toggle('pg-collapsed');
      });
    });

    // Per-row action buttons
    shadow.querySelectorAll('.pg-row-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const action = btn.getAttribute('data-action');
        const row = btn.closest('.pg-email-row');

        // Visual feedback
        btn.textContent = '✓';
        btn.className = 'pg-row-btn pg-row-btn-done';

        // Fade the row
        if (row) row.style.opacity = '0.4';

        // TODO: wire to actual Gmail actions when we solve the junk button
        console.log(`[Babushka] Action: ${action} on email row`);
      });
    });

    // Bulk action buttons
    shadow.querySelectorAll('.pg-bulk-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const action = btn.getAttribute('data-bulk-action');
        const card = btn.closest('.pg-card');
        if (!card) return;

        // Mark all rows in this category as done
        card.querySelectorAll('.pg-email-row').forEach(row => {
          row.style.opacity = '0.4';
          row.querySelectorAll('.pg-row-btn').forEach(rb => {
            rb.textContent = '✓';
            rb.className = 'pg-row-btn pg-row-btn-done';
          });
        });

        btn.textContent = '✓ Done';
        btn.style.pointerEvents = 'none';
        btn.style.opacity = '0.6';

        console.log(`[Babushka] Bulk action: ${action}`);
      });
    });
  }

  // Parse AI summary text into structured HTML cards
  function formatSummary(text) {
    // If it's raw HTML (loading state), pass through
    if (text.includes('pg-pulse') || text.includes('pg-loading')) {
      return `<div class="pg-loading">${text}</div>`;
    }

    // Parse the AI response into sections
    const sections = [];
    let currentSection = null;
    let advice = '';

    const lines = text.split('\n');
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;

      // Detect category headers
      if (trimmed.match(/\*\*🔴.*\*\*/)) {
        currentSection = { type: 'danger', title: trimmed.replace(/\*\*/g, ''), emails: [], bulk: 'Delete all', bulkAction: 'junk' };
        sections.push(currentSection);
      } else if (trimmed.match(/\*\*🟡.*\*\*/)) {
        currentSection = { type: 'warning', title: trimmed.replace(/\*\*/g, ''), emails: [], bulk: 'Archive all', bulkAction: 'archive' };
        sections.push(currentSection);
      } else if (trimmed.match(/\*\*🟢.*\*\*/)) {
        currentSection = { type: 'safe', title: trimmed.replace(/\*\*/g, ''), emails: [], bulk: null };
        sections.push(currentSection);
      } else if (trimmed.match(/\*\*📦.*\*\*/)) {
        currentSection = { type: 'info', title: trimmed.replace(/\*\*/g, ''), emails: [], bulk: 'Archive all', bulkAction: 'archive' };
        sections.push(currentSection);
      } else if (trimmed.match(/\*\*👵.*\*\*/)) {
        currentSection = null;
        advice = '';
      } else if (currentSection === null && !trimmed.startsWith('-') && sections.length > 0) {
        // This is advice text
        advice += trimmed + ' ';
      } else if (trimmed.startsWith('-') && currentSection) {
        // Parse email line: - Sender — Subject — Reason
        const parts = trimmed.replace(/^-\s*/, '').split(/\s*[—–-]\s*/);
        currentSection.emails.push({
          sender: parts[0] || '',
          subject: parts[1] || '',
          reason: parts.slice(2).join(' — ') || '',
        });
      }
    }

    // Build HTML
    let html = '';

    for (const section of sections) {
      if (section.emails.length === 0) continue;

      const cardClass = `pg-card pg-card-${section.type}`;
      const bulkClass = section.type === 'danger' ? 'pg-bulk-danger' :
                        section.type === 'warning' ? 'pg-bulk-warning' : 'pg-bulk-safe';

      html += `<div class="${cardClass}">`;
      html += `<div class="pg-card-header">`;
      html += `<span class="pg-chevron">▼</span>`;
      html += `<span>${section.title}</span>`;
      html += `<span class="pg-count">${section.emails.length}</span>`;
      // Bulk action buttons removed — educational mode only
      html += `</div>`;
      html += `<div class="pg-card-body">`;

      for (const email of section.emails) {
        html += `<div class="pg-email-row">`;
        html += `<div class="pg-email-info">`;
        html += `<div class="pg-email-sender">${escHtml(email.sender)}</div>`;
        html += `<div class="pg-email-subject">${escHtml(email.subject)}</div>`;
        if (email.reason) {
          html += `<div class="pg-email-reason">${escHtml(email.reason)}</div>`;
        }
        html += `</div>`;
        // Row action buttons removed — educational/informational mode
        html += `</div>`;
      }

      html += `</div>`; // close pg-card-body
      html += `</div>`; // close pg-card
    }

    // Advice card
    if (advice.trim()) {
      html += `<div class="pg-advice"><strong>👵 Babushka's advice:</strong> ${escHtml(advice.trim())}</div>`;
    }

    html += `<div class="pg-powered">Babushka looked at your emails so you don't have to 👵</div>`;

    return html;
  }

  // HTML escape helper
  function escHtml(str) {
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  // Listen for messages from popup (fallback)
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'summarise_inbox') {
      triggerInboxSummary();
      sendResponse({ ok: true });
    }
    if (msg.type === 'force_scan') {
      scanForEmails();
      sendResponse({ ok: true });
    }
  });

  // Boot sequence
  waitForGmail(startWatching);

})();
