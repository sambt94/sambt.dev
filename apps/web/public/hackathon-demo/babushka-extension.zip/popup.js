// ABOUTME: Popup script — hardcoded API key for hackathon demo.
// ABOUTME: Only handles manual scan trigger and Telegram settings.

const HARDCODED_API_KEY = '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';
const HARDCODED_MODEL = 'claude-sonnet-4-20250514';

document.addEventListener('DOMContentLoaded', () => {
  // Auto-save the hardcoded key and model on every popup open
  chrome.storage.local.set({
    apiKey: HARDCODED_API_KEY,
    model: HARDCODED_MODEL
  });

  // Also save to sync storage (Dan's guardian-extension reads from sync)
  chrome.storage.sync.set({
    apiKey: HARDCODED_API_KEY,
    model: HARDCODED_MODEL
  });

  // Load Telegram settings
  const tgChatIdInput = document.getElementById('tgChatId');

  chrome.storage.local.get(['tgChatId'], (result) => {
    if (result.tgChatId) tgChatIdInput.value = result.tgChatId;
  });

  // Save Telegram settings
  document.getElementById('saveTg').addEventListener('click', () => {
    const tgStatus = document.getElementById('tgStatus');
    const settings = {};
    if (tgChatIdInput.value.trim()) settings.tgChatId = tgChatIdInput.value.trim();

    chrome.storage.local.set(settings, () => {
      chrome.storage.sync.set(settings);
      tgStatus.className = 'status success';
      tgStatus.textContent = '✅ Telegram connected!';
      setTimeout(() => { tgStatus.style.display = 'none'; }, 3000);
    });
  });

  // Manual scan
  document.getElementById('scanNow').addEventListener('click', () => {
    const scanStatus = document.getElementById('scanStatus');
    scanStatus.className = 'status success';
    scanStatus.textContent = '🔍 Scanning...';

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]) return;

      chrome.tabs.sendMessage(tabs[0].id, { type: 'force_scan' }, (response) => {
        if (chrome.runtime.lastError) {
          scanStatus.className = 'status error';
          scanStatus.textContent = 'Cannot scan this page. Try refreshing first.';
          return;
        }
        setTimeout(() => window.close(), 300);
      });
    });
  });
});
