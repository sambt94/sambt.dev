// ABOUTME: Popup script for API key entry, model selection, and manual scan trigger.
// ABOUTME: Uses chrome.storage.local consistently. Tests service worker connection.

document.addEventListener('DOMContentLoaded', () => {
  const apiKeyInput = document.getElementById('apiKey');
  const modelSelect = document.getElementById('model');
  const saveBtn = document.getElementById('save');
  const statusEl = document.getElementById('status');
  const scanBtn = document.getElementById('scanNow');
  const scanStatus = document.getElementById('scanStatus');

  const tgBotTokenInput = document.getElementById('tgBotToken');
  const tgChatIdInput = document.getElementById('tgChatId');

  // Load saved settings
  chrome.storage.local.get(['apiKey', 'model', 'tgBotToken', 'tgChatId'], (result) => {
    if (result.apiKey) apiKeyInput.value = result.apiKey;
    if (result.model) modelSelect.value = result.model;
    if (result.tgBotToken) tgBotTokenInput.value = result.tgBotToken;
    if (result.tgChatId) tgChatIdInput.value = result.tgChatId;
  });

  // Save settings
  saveBtn.addEventListener('click', () => {
    const apiKey = apiKeyInput.value.trim();
    const model = modelSelect.value;

    if (!apiKey) {
      statusEl.className = 'status error';
      statusEl.textContent = 'Please enter an API key';
      return;
    }

    if (!apiKey.startsWith('sk-ant-')) {
      statusEl.className = 'status error';
      statusEl.textContent = 'API key should start with sk-ant-';
      return;
    }

    const settings = { apiKey, model };
    if (tgBotTokenInput.value.trim()) settings.tgBotToken = tgBotTokenInput.value.trim();
    if (tgChatIdInput.value.trim()) settings.tgChatId = tgChatIdInput.value.trim();

    chrome.storage.local.set(settings, () => {
      statusEl.className = 'status success';
      statusEl.textContent = '✅ Saved! Babushka is watching over you.';
      setTimeout(() => { statusEl.style.display = 'none'; }, 3000);
    });
  });

  // Summarise inbox
  const summariseBtn = document.getElementById('summarise');
  const summaryStatus = document.getElementById('summaryStatus');

  summariseBtn.addEventListener('click', () => {
    chrome.storage.local.get(['apiKey'], (result) => {
      if (!result.apiKey) {
        summaryStatus.className = 'status error';
        summaryStatus.textContent = 'Save your API key first';
        return;
      }

      summaryStatus.className = 'status success';
      summaryStatus.textContent = '👵 Babushka is reading your inbox...';

      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (!tabs[0]) return;
        chrome.tabs.sendMessage(tabs[0].id, { type: 'summarise_inbox' }, (response) => {
          if (chrome.runtime.lastError) {
            summaryStatus.className = 'status error';
            summaryStatus.textContent = 'Open Gmail first, then try again.';
            return;
          }
          setTimeout(() => window.close(), 300);
        });
      });
    });
  });

  // Manual scan
  scanBtn.addEventListener('click', () => {
    chrome.storage.local.get(['apiKey'], (result) => {
      if (!result.apiKey) {
        scanStatus.className = 'status error';
        scanStatus.textContent = 'Save your API key first';
        return;
      }

      scanStatus.className = 'status success';
      scanStatus.textContent = '🔍 Scanning...';

      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (!tabs[0]) return;

        chrome.tabs.sendMessage(tabs[0].id, { type: 'force_scan' }, (response) => {
          if (chrome.runtime.lastError) {
            scanStatus.className = 'status error';
            scanStatus.textContent = 'Cannot scan this page. Try refreshing first.';
            return;
          }
          // Close popup after a short delay
          setTimeout(() => window.close(), 300);
        });
      });
    });
  });
});
