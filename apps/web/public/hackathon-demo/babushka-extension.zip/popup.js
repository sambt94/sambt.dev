// ABOUTME: Popup script for Babushka extension.
// ABOUTME: Manages API key setup, settings, Telegram config, and manual scan trigger.

const DEFAULT_MODEL = 'claude-sonnet-4-20250514';

document.addEventListener('DOMContentLoaded', () => {
  const setupView = document.getElementById('setupView');
  const mainView = document.getElementById('mainView');
  const settingsView = document.getElementById('settingsView');

  function showView(view) {
    setupView.classList.add('hidden');
    mainView.classList.add('hidden');
    settingsView.classList.add('hidden');
    view.classList.remove('hidden');
  }

  // Check if API key exists — show setup or main view
  chrome.storage.local.get(['apiKey', 'model', 'tgChatId'], (result) => {
    if (result.apiKey) {
      showView(mainView);
      // Load Telegram chat ID
      const tgInput = document.getElementById('tgChatId');
      if (result.tgChatId) tgInput.value = result.tgChatId;
    } else {
      showView(setupView);
    }
  });

  // SETUP: Save API key for first time
  document.getElementById('setupSave').addEventListener('click', () => {
    const key = document.getElementById('setupApiKey').value.trim();
    const status = document.getElementById('setupStatus');

    if (!key || !key.startsWith('sk-ant-')) {
      status.className = 'status error';
      status.textContent = 'Please enter a valid Claude API key';
      return;
    }

    const settings = { apiKey: key, model: DEFAULT_MODEL };
    chrome.storage.local.set(settings, () => {
      chrome.storage.sync.set(settings);
      showView(mainView);
    });
  });

  // SETTINGS: Open settings view
  document.getElementById('openSettings').addEventListener('click', () => {
    chrome.storage.local.get(['apiKey', 'model'], (result) => {
      document.getElementById('settingsApiKey').value = result.apiKey || '';
      document.getElementById('settingsModel').value = result.model || DEFAULT_MODEL;
      showView(settingsView);
    });
  });

  // SETTINGS: Back to main
  document.getElementById('backToMain').addEventListener('click', () => {
    showView(mainView);
  });

  // SETTINGS: Save
  document.getElementById('settingsSave').addEventListener('click', () => {
    const key = document.getElementById('settingsApiKey').value.trim();
    const model = document.getElementById('settingsModel').value.trim() || DEFAULT_MODEL;
    const status = document.getElementById('settingsStatus');

    if (!key || !key.startsWith('sk-ant-')) {
      status.className = 'status error';
      status.textContent = 'Please enter a valid Claude API key';
      return;
    }

    const settings = { apiKey: key, model: model };
    chrome.storage.local.set(settings, () => {
      chrome.storage.sync.set(settings);
      status.className = 'status success';
      status.textContent = '✅ Settings saved!';
      setTimeout(() => { status.style.display = 'none'; }, 2000);
    });
  });

  // TELEGRAM: Save
  document.getElementById('saveTg').addEventListener('click', () => {
    const tgStatus = document.getElementById('tgStatus');
    const chatId = document.getElementById('tgChatId').value.trim();
    const settings = {};
    if (chatId) settings.tgChatId = chatId;

    chrome.storage.local.set(settings, () => {
      chrome.storage.sync.set(settings);
      tgStatus.className = 'status success';
      tgStatus.textContent = '✅ Telegram connected!';
      setTimeout(() => { tgStatus.style.display = 'none'; }, 3000);
    });
  });

  // SCAN: Manual scan
  document.getElementById('scanNow').addEventListener('click', () => {
    const scanStatus = document.getElementById('scanStatus');
    scanStatus.className = 'status success';
    scanStatus.textContent = '🔍 Scanning...';

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]) return;

      chrome.tabs.sendMessage(tabs[0].id, { type: 'force_scan' }, (response) => {
        if (chrome.runtime.lastError) {
          scanStatus.className = 'status error';
          scanStatus.textContent = 'Cannot scan this page. Try refreshing first.';
          return;
        }
        setTimeout(() => window.close(), 300);
      });
    });
  });
});
